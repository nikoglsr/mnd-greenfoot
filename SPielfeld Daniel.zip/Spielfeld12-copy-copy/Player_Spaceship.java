/**
 * Write a description of class Player_Spaceship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player_Spaceship extends Obejcts
{
  public int leben;
  public boolean tot;
  public int xPos;
  public int yPos;
  
  public void Player_Spaceship()
  {
    }
  public void bewegen (int X, int Y)
  {
    }
  public int getX ()
  {
    }
  public int getY ()
  {
    }
 
  public void SetX (int X)
  {
    }
  public void SetY (int Y)
  {
    }
  public void schiessen (s Schuss)
  {
    }
  public void lebenVerlieren (int leben)
  {
    }
  public void setImage()
  {
    }
}
