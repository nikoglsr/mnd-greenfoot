/**
 * Write a description of class Enemy_Spaceship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemy_Spaceship extends Obejcts
{
    public boolean tot;
    public int leben;
   
    public Enemy_Spaceship()
    {
    }
    public void autoBewegen (int x, int y)
    {
    }
    public int getX()
    {
      
    }
    public int getY()
    {
    }
    public void SetX(int X)
    {
    }
    public void SetY(int Y)
    {
    }
    public void schießen (Schuss s)
    {
    }
    public void spawnen (int x, int y)
    {
    }
    public void despawnen (boolean tot)
    {
    }
    public void lebenVerlieren()
    {
    }
    public void setImage()
    {
    }
    
}
