/**
 * Write a description of class Optionen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Optionen 
{
  public boolean aktivStartGame;
  public boolean aktivStopGame;
  public boolean aktivGameOver;
  
  public void startGame()
  {
    }
  public void stopGame()
  {
    }
   public void gameOver()
   {
    }
}
