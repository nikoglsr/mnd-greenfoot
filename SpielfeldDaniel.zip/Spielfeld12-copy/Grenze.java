/**
 * Write a description of class Grenze here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Grenze extends Enemy_Spaceship 
{
   public int xPos;
   public int yPos;
   public void setImage()
   {
    }
}
