/**
 * Write a description of class Space_World here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Space_World extends Optionen
{
    
    
}
